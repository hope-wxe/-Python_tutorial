#python基础语法
#python保留关键字
import keyword
import numbers
print(numbers.__all__)
print(keyword.kwlist)
'''
第一个注释
'''
"""
第二个注释
"""
#注释
str='runoob'
print(str)          #输出字符串
print(str[0:-1])    #输出第一个到倒数第二个字符
print(str[0])       #输出第一个字符
print(str[2:5])     #输出第三个到第五个字符
print(str[2:])      #输出第三个到结束
print(str*2)        #输出字符串两次
print(str+'你好')     #连接字符串
print(".....................")
print('runoob\nhello world!')
print(r'runoob\nhello world')   #字符串前加一个 r 表示原始字符串，不会发生转义



#空行
#input('\n\n按下 enter 键退出。')#接收用户输入
#import sys;x = 'runoob';sys.stdout.write(x+'\n')
x='a'
y='b'
print(x)
print(y)
print('........')
print(x,end="")
print(y,end="\n")
from sys import argv,path
print(path)