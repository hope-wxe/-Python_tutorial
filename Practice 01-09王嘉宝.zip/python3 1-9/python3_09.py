#python3数字

number=0x37     #十六进制

print(number)
#数字类型转换
a=1.0

print(int(a))
#  +,-,*,/,%,//,**
#数学常量 pi为Π，e为自然常数