#python3运算符

#算数运算符
a=5
b=3
print(a//b)
print(a%b)
print(a**b)
#比较运算符
if(a==b):
    print('a=b')
elif(a>b):
    print('a>b')
else:
    print(a<b)
if(a!=b):
    print("a!=b")
else:
    print('a=b')
#成员运算符 in :not in
a=10
b=20
list=[10,30,40]
if(a in list):
    print('a in list')
else:
    print('a not in list')
#身份运算符 is;not is
a=10;b=10
if(a is b):
    print('a is b')
else:
    print('a is not b')