#第一个python小程序
print("Hello World!")
#输出hello World