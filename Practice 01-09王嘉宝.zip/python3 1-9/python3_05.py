#python3基本数据类型
#数字
counter=100
miles=100.0
name='runoob'
print(counter,miles,name)
a,b,c=1,1.2,'runoob'                #多变量赋值
print(type(b))
print(isinstance(a,int))            #判断数据类型
print(5+4)
#字符串
str='runoob'
print(str[0])
print(str[-6])          #str[0]='m'是错误的，字符串不能改变
#列表
list=['a','b','c',123,1.25]
liebiao=[1,2,3]
print(list)
print(list[:2])
print(list[1:3])
print(list*2)          #输出两次
print(list+liebiao)    #连接列表
list[0]=1
print(list)            #列表值可改变
#元组
tuple=(1,2,'run','a')           #元素值不能改变
tup1=()                         #空元组
tup2=(20,)                      #一个元素的元组
#集合
set()           #创建空集合
parame={'value01','value02'}
#字典     键(key):值(value)
dictb={'name':'runoob','code':6,'site':'www.runoob.com'}
print(dictb.keys())    #键必须是唯一的
print(dictb.values())
dict={}                 #创建空字典
dict['one']="1-菜鸟教程"
dict[2]='2-菜鸟'
print(dict['one'])      #输出键为‘one’的值
print(dict[2])
print(dict)
